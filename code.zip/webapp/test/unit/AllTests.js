sap.ui.define([
	"yegeoaiso/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
