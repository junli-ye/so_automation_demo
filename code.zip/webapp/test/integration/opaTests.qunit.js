/* global QUnit */

sap.ui.require(["yegeoaiso/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
